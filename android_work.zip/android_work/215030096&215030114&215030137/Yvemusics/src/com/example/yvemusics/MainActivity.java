package com.example.yvemusics;

import android.app.Activity;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;


public class MainActivity extends Activity {
	public MediaPlayer Yve;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        Button btnstart = (Button )findViewById(R.id.btnstart);
        Button btnstop = (Button )findViewById(R.id.btnstop);
        Button ex=(Button)findViewById(R.id.btnexit);
        ex.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				finish();
				System.exit(0);
				
			}
		});
        
        
        
btnstart.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				onCreate();
				//Toast.makeText(ToastMessage.this, "Iratangiye muryoherwe!", Toast.LENGTH_LONG).show();
				
			}
			
		});
        btnstop.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				onDestroy();
				//Toast.makeText(Music.this, "Service stoped", Toast.LENGTH_LONG).show();
				
			}
		});
        
    }
   
    
    public void onCreate(){
    	Toast.makeText(this, " song is started", Toast.LENGTH_LONG).show();
    	Yve=MediaPlayer.create(this, R.raw.mus);
    	Yve.setLooping(false);
    	Yve.start();

    }
    public void onDestroy(){
    	Toast.makeText(this, "song is Stoped", Toast.LENGTH_LONG).show();
    	Yve.pause();
    	
        }
}
